# Sound Files Directory

Place notification sound files here:
- order-notification.mp3 (for new orders)
- success.mp3 (for successful actions)
- alert.mp3 (for warnings)